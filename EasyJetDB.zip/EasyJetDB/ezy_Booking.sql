-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 14, 2019 at 12:57 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drice21`
--

-- --------------------------------------------------------

--
-- Table structure for table `ezy_Booking`
--

CREATE TABLE `ezy_Booking` (
  `BookingID` int(11) NOT NULL,
  `CustomerID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ezy_Booking`
--

INSERT INTO `ezy_Booking` (`BookingID`, `CustomerID`) VALUES
(24, 11),
(2, 15),
(32, 15),
(8, 16),
(38, 16),
(29, 17),
(9, 18),
(39, 18),
(22, 19),
(20, 20),
(50, 20),
(23, 21),
(28, 26),
(27, 27),
(4, 28),
(34, 28),
(16, 29),
(46, 29),
(3, 30),
(33, 30),
(26, 31),
(15, 32),
(45, 32),
(19, 33),
(49, 33),
(6, 34),
(36, 34),
(5, 35),
(35, 35),
(17, 36),
(47, 36),
(10, 37),
(40, 37),
(7, 38),
(37, 38),
(30, 39),
(25, 40),
(12, 41),
(42, 41),
(13, 73),
(43, 73),
(14, 74),
(44, 74),
(11, 75),
(41, 75),
(1, 98),
(31, 98),
(18, 99),
(48, 99),
(21, 100),
(91, 101),
(92, 101),
(93, 102);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ezy_Booking`
--
ALTER TABLE `ezy_Booking`
  ADD PRIMARY KEY (`BookingID`),
  ADD KEY `FK_CustomerIDToBooking` (`CustomerID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ezy_Booking`
--
ALTER TABLE `ezy_Booking`
  MODIFY `BookingID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ezy_Booking`
--
ALTER TABLE `ezy_Booking`
  ADD CONSTRAINT `FK_CustomerIDToBooking` FOREIGN KEY (`CustomerID`) REFERENCES `ezy_Customers` (`CustomerID`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
