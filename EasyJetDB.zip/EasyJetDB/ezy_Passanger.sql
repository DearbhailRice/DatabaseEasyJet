-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 14, 2019 at 12:58 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drice21`
--

-- --------------------------------------------------------

--
-- Table structure for table `ezy_Passanger`
--

CREATE TABLE `ezy_Passanger` (
  `PassangerID` int(11) NOT NULL,
  `TitleID` int(11) NOT NULL,
  `FirstName` varchar(255) NOT NULL,
  `Lastname` varchar(255) NOT NULL,
  `PassangerAgeCategory` int(11) NOT NULL,
  `BookingID` int(11) NOT NULL,
  `Easyjet+ID` int(11) DEFAULT NULL,
  `PassangerAssistanceTypeID` int(11) DEFAULT NULL,
  `PassportID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ezy_Passanger`
--

INSERT INTO `ezy_Passanger` (`PassangerID`, `TitleID`, `FirstName`, `Lastname`, `PassangerAgeCategory`, `BookingID`, `Easyjet+ID`, `PassangerAssistanceTypeID`, `PassportID`) VALUES
(3, 2, ' Hector', ' Albert', 1, 1, 28, 11, 176),
(4, 2, ' Lani', ' Carey', 3, 2, 31, 6, 182),
(5, 3, ' Ina', ' Lee', 1, 2, 29, 6, 107),
(6, 4, ' Victor', ' Price', 2, 3, 33, 9, 176),
(7, 1, ' Hakeem', ' Rice', 2, 3, 50, 6, 119),
(9, 4, ' Imelda', ' Lowery', 1, 4, 29, 6, 198),
(10, 2, ' Rashad', ' Bennett', 1, 4, 30, 8, 196),
(12, 4, ' Fatima', ' Crane', 3, 6, 28, 6, 107),
(14, 3, ' Gannon', ' Michael', 1, 7, 37, 10, 125),
(15, 3, ' Teagan', ' Walters', 2, 7, 39, 10, 155),
(19, 4, ' Cadman', ' Nieves', 3, 8, 48, 11, 162),
(20, 1, ' Raya', ' Holt', 2, 10, 27, 8, 111),
(21, 2, ' Vera', ' Chen', 2, 10, 50, 6, 167),
(22, 3, ' Gloria', ' Rosales', 1, 10, 48, 7, 134),
(23, 3, ' Shoshana', ' Bolton', 3, 10, 41, 9, 160),
(24, 1, ' Hammett', ' Alford', 3, 11, 44, 7, 176),
(25, 3, ' Merrill', ' Lindsey', 2, 11, 37, 7, 115),
(27, 1, ' Cecilia', ' Powers', 3, 12, 36, 9, 187),
(29, 3, ' Dolan', ' Cooley', 3, 14, 49, 9, 131),
(30, 1, ' Hollee', ' Hoffman', 1, 15, 30, 10, 150),
(31, 3, ' Byron', ' Madden', 1, 15, 39, 10, 104),
(33, 3, ' Tucker', ' Beasley', 1, 16, 38, 6, 154),
(35, 4, ' Upton', ' Perkins', 2, 17, 46, 11, 167),
(37, 1, ' Buffy', ' Bailey', 1, 18, 50, 6, 151),
(38, 3, ' Zeph', ' Chase', 2, 18, 45, 8, 157),
(40, 1, ' Flynn', ' Mckee', 2, 19, 44, 11, 187),
(41, 1, ' Colby', ' Haney', 1, 19, 32, 8, 157),
(43, 3, ' Jamalia', ' Sharpe', 3, 20, 38, 6, 198),
(44, 1, ' Brendan', ' Phelps', 2, 20, 45, 8, 167),
(45, 3, ' Aladdin', ' Booker', 1, 20, 32, 9, 154),
(46, 1, ' Rae', ' Bonner', 2, 23, 49, 8, 173),
(47, 4, ' Adena', ' Ellis', 3, 23, 29, 9, 150),
(48, 3, ' Iris', ' Stephens', 2, 24, 51, 9, 199),
(49, 3, ' Tara', ' Tucker', 3, 24, 30, 6, 117),
(51, 2, ' Travis', ' Franklin', 1, 25, 35, 9, 130),
(52, 3, ' Noble', ' Ashley', 1, 26, 33, 9, 179),
(53, 3, ' Dean', ' Graves', 3, 27, 28, 11, 185),
(54, 2, ' Cameron', ' Bell', 1, 27, 50, 10, 117),
(55, 1, ' Joelle', ' Smith', 3, 28, 42, 6, 127),
(58, 4, ' Darryl', ' Floyd', 2, 29, 33, 8, 164),
(59, 3, ' Keaton', ' Barrera', 1, 29, 39, 11, 164),
(60, 3, ' Regina', ' Hansen', 2, 29, 45, 11, 170),
(61, 4, ' Sean', ' Diaz', 2, 31, 48, 10, 103),
(62, 3, ' Chester', ' Perez', 1, 32, 35, 10, 160),
(63, 1, ' Neil', ' Talley', 2, 32, 27, 6, 176),
(64, 4, ' Chester', ' Olson', 3, 32, 39, 8, 131),
(65, 4, ' Mason', ' George', 2, 32, 46, 7, 193),
(66, 4, ' Ria', ' Combs', 3, 34, 38, 7, 173),
(67, 4, ' Wing', ' Gates', 3, 34, 36, 10, 182),
(68, 1, ' Eaton', ' Clark', 3, 34, 47, 11, 122),
(70, 3, ' Mia', ' Newman', 3, 35, 27, 9, 128),
(71, 3, ' Tobias', ' Garrison', 1, 35, 48, 10, 158),
(72, 3, ' Xander', ' Terrell', 3, 37, 37, 7, 132),
(74, 3, ' Ulla', ' Hoffman', 2, 38, 39, 6, 155),
(75, 1, ' Fitzgerald', ' Horton', 2, 38, 51, 9, 173),
(76, 4, ' Carissa', ' Nichols', 3, 38, 36, 11, 185),
(77, 3, ' Lysandra', ' Rosales', 2, 39, 29, 9, 198),
(78, 1, ' Branden', ' Mcneil', 3, 39, 32, 11, 169),
(79, 2, ' Cassandra', ' Snyder', 3, 39, 51, 6, 129),
(80, 4, ' Fallon', ' Coffey', 2, 39, 45, 11, 149),
(81, 3, ' Hayley', ' Chavez', 1, 40, 37, 8, 173),
(82, 1, ' Catherine', ' Underwood', 3, 40, 34, 11, 109),
(84, 3, ' Michael', ' Howe', 2, 41, 51, 7, 162),
(85, 2, ' Amelia', ' Compton', 3, 42, 49, 7, 190),
(86, 1, ' Quentin', ' Sheppard', 1, 43, 35, 7, 119),
(87, 4, ' Nora', ' Reed', 3, 43, 44, 6, 138),
(88, 3, ' Luke', ' Anthony', 3, 43, 34, 11, 167),
(89, 4, ' Quamar', ' Peterson', 3, 43, 33, 9, 158),
(90, 3, ' Kadeem', ' Pope', 3, 44, 51, 9, 125),
(91, 3, ' Alec', ' Molina', 3, 45, 51, 8, 149),
(94, 2, ' Kaitlin', ' Parker', 3, 46, 39, 11, 125),
(95, 4, ' Barry', ' Boone', 3, 46, 49, 6, 157),
(96, 3, ' Raja', ' Haney', 3, 47, 36, 8, 192),
(97, 4, ' Quemby', ' Simpson', 2, 47, 45, 11, 188),
(100, 2, ' Sandra', ' Duran', 3, 48, 40, 11, 104),
(101, 1, ' Coby', ' Watts', 2, 50, 34, 6, 103),
(102, 2, ' Tanek', ' Hood', 2, 50, 40, 10, 171),
(103, 3, 'Harleen Frances ', 'Quinzel', 3, 93, NULL, 11, 201);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ezy_Passanger`
--
ALTER TABLE `ezy_Passanger`
  ADD PRIMARY KEY (`PassangerID`),
  ADD KEY `FK_TitlID` (`TitleID`),
  ADD KEY `FK_PassangerAgeCategory` (`PassangerAgeCategory`),
  ADD KEY `FK_BookingIDToPassanger` (`BookingID`),
  ADD KEY `FK_PassportID` (`PassportID`),
  ADD KEY `FK_passangerAssistanceTypr` (`PassangerAssistanceTypeID`),
  ADD KEY `FK_EasyJet+ID` (`Easyjet+ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ezy_Passanger`
--
ALTER TABLE `ezy_Passanger`
  MODIFY `PassangerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ezy_Passanger`
--
ALTER TABLE `ezy_Passanger`
  ADD CONSTRAINT `FK_BookingIDToPassanger` FOREIGN KEY (`BookingID`) REFERENCES `ezy_Booking` (`BookingID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_EasyJet+ID` FOREIGN KEY (`Easyjet+ID`) REFERENCES `ezy_EJ+` (`EJ+ID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_PassangerAgeCategory` FOREIGN KEY (`PassangerAgeCategory`) REFERENCES `ezy_PasangerAgeCategory` (`PasangerAgeCategoryID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_PassportID` FOREIGN KEY (`PassportID`) REFERENCES `ezy_Passport` (`PassportID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_TitlID` FOREIGN KEY (`TitleID`) REFERENCES `ezy_Title` (`TitleID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_passangerAssistanceTypr` FOREIGN KEY (`PassangerAssistanceTypeID`) REFERENCES `ezy_PassangerAssistanceType` (`PassangerAssistanceTypeID`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
