-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 14, 2019 at 12:59 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drice21`
--

-- --------------------------------------------------------

--
-- Table structure for table `ezy_SeatSelection`
--

CREATE TABLE `ezy_SeatSelection` (
  `SeatSelectionID` int(11) NOT NULL,
  `FlightID` int(11) NOT NULL,
  `SeatMapID` int(11) DEFAULT NULL,
  `SeatPreSelected` tinyint(1) NOT NULL,
  `BookingID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ezy_SeatSelection`
--

INSERT INTO `ezy_SeatSelection` (`SeatSelectionID`, `FlightID`, `SeatMapID`, `SeatPreSelected`, `BookingID`) VALUES
(1, 12, 224, 1, 6),
(2, 45, 186, 1, 17),
(5, 22, 156, 1, 19),
(7, 29, 186, 1, 5),
(8, 43, 223, 1, 3),
(9, 42, 220, 1, 8),
(10, 74, 214, 1, 9),
(12, 89, 171, 0, 4),
(16, 79, 164, 0, 16),
(18, 24, 213, 1, 14),
(19, 43, 168, 0, 11),
(20, 79, 169, 0, 5),
(22, 29, 208, 1, 24),
(23, 49, 152, 1, 13),
(27, 57, 227, 0, 25),
(28, 74, 228, 1, 1),
(32, 52, 154, 0, 15),
(34, 22, 179, 0, 2),
(38, 49, 153, 0, 8),
(39, 23, 218, 0, 18),
(42, 36, 185, 0, 13),
(43, 79, 229, 0, 8),
(48, 66, 210, 0, 21),
(51, 11, 166, 1, 91),
(52, 12, 151, 1, 93),
(53, 18, 151, 1, 93);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ezy_SeatSelection`
--
ALTER TABLE `ezy_SeatSelection`
  ADD PRIMARY KEY (`SeatSelectionID`),
  ADD KEY `FK_FlightID` (`FlightID`),
  ADD KEY `FK_SeatMapID` (`SeatMapID`),
  ADD KEY `FK_BookingIDToSeatselection` (`BookingID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ezy_SeatSelection`
--
ALTER TABLE `ezy_SeatSelection`
  MODIFY `SeatSelectionID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ezy_SeatSelection`
--
ALTER TABLE `ezy_SeatSelection`
  ADD CONSTRAINT `FK_BookingIDToSeatselection` FOREIGN KEY (`BookingID`) REFERENCES `ezy_Booking` (`BookingID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_FlightID` FOREIGN KEY (`FlightID`) REFERENCES `ezy_Flight` (`FlightID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_SeatMapID` FOREIGN KEY (`SeatMapID`) REFERENCES `ezy_SeatMap` (`SeatMapID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
