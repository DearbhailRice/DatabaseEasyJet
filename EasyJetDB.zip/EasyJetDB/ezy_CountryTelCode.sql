-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 14, 2019 at 12:58 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drice21`
--

-- --------------------------------------------------------

--
-- Table structure for table `ezy_CountryTelCode`
--

CREATE TABLE `ezy_CountryTelCode` (
  `CountryTelCodeID` int(11) NOT NULL,
  `CountryTelCode` varchar(255) NOT NULL,
  `contryID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ezy_CountryTelCode`
--

INSERT INTO `ezy_CountryTelCode` (`CountryTelCodeID`, `CountryTelCode`, `contryID`) VALUES
(1, ' \'93\'', 4),
(2, ' \'297\'', 6),
(3, ' \'61\'', 5),
(4, ' \'1242\'', 7),
(5, ' \'267\'', 8),
(6, ' \'257\'', 9),
(7, ' \'855\'', 10),
(8, ' \'57\'', 11),
(9, ' \'420\'', 12),
(10, ' \'45\'', 13),
(11, ' \'1809\'', 14),
(12, ' \'1809\'', 15),
(13, ' \'593\'', 16),
(14, ' \'372\'', 17),
(15, ' \'678\'', 18),
(16, ' \'33\'', 19),
(17, ' \'49\'', 20),
(18, ' \'233\'', 21),
(19, ' \'509\'', 22),
(20, ' \'36\'', 23),
(21, ' \'354\'', 24),
(22, ' \'91\'', 25),
(24, ' \'1876\'', 26),
(25, ' \'81\'', 27),
(26, ' \'254\'', 29),
(27, ' \'965\'', 28),
(28, ' \'856\'', 30),
(29, ' \'352\'', 31),
(30, ' \'853\'', 32),
(31, ' \'52\'', 33),
(32, ' \'31\'', 34),
(33, ' \'64\'', 35),
(34, ' \'44\'', 3),
(35, ' \'968\'', 36),
(36, ' \'92\'', 37),
(37, ' \'51\'', 38),
(38, ' \'974\'', 39),
(39, ' \'40\'', 41),
(40, ' \'7\'', 40),
(41, ' \'685\'', 42),
(42, ' \'381\'', 43),
(43, ' \'66\'', 44),
(44, ' \'676\'', 45),
(45, ' \'380\'', 47),
(47, ' \'1\'', 46),
(48, ' \'84\'', 48),
(49, ' \'212\'', 49),
(50, ' \'967\'', 50),
(51, ' \'263\'', 51);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ezy_CountryTelCode`
--
ALTER TABLE `ezy_CountryTelCode`
  ADD PRIMARY KEY (`CountryTelCodeID`),
  ADD KEY `FK_CountryTOTelCode` (`contryID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ezy_CountryTelCode`
--
ALTER TABLE `ezy_CountryTelCode`
  MODIFY `CountryTelCodeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ezy_CountryTelCode`
--
ALTER TABLE `ezy_CountryTelCode`
  ADD CONSTRAINT `FK_CountryTOTelCode` FOREIGN KEY (`contryID`) REFERENCES `ezy_Country` (`CountryID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
