-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 14, 2019 at 12:56 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drice21`
--

-- --------------------------------------------------------

--
-- Table structure for table `ezy_Aircraft`
--

CREATE TABLE `ezy_Aircraft` (
  `AircraftID` int(11) NOT NULL,
  `AircraftReg` varchar(11) NOT NULL,
  `AircraftTypeID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ezy_Aircraft`
--

INSERT INTO `ezy_Aircraft` (`AircraftID`, `AircraftReg`, `AircraftTypeID`) VALUES
(101, 'J7D 2K2', 1),
(102, 'D0T 6D3', 2),
(103, 'Q6T 0B8', 3),
(104, 'F6S 6E8', 4),
(105, 'N3M 9B5', 1),
(106, 'T6O 0J5', 2),
(107, 'K0J 9B8', 4),
(108, 'S6D 8D2', 3),
(109, 'O0T 8W7', 1),
(110, 'V8V 0F5', 1),
(111, 'E1A 4L0', 4),
(112, 'F5B 7V3', 3),
(113, 'X2T 5H3', 4),
(114, 'I2H 8O3', 2),
(115, 'V0H 3J0', 3),
(116, 'C7T 3O0', 2),
(117, 'B1I 9F2', 1),
(118, 'Z8C 5L0', 3),
(119, 'T4C 3B2', 4),
(120, 'L7T 3U9', 1),
(121, 'X5F 0B7', 3),
(122, 'Y5Q 6W5', 1),
(123, 'J1R 7L0', 4),
(124, 'X0D 0N5', 4),
(125, 'C5W 4Q1', 2),
(126, 'B9I 8W3', 2),
(127, 'W2A 0H4', 3),
(128, 'R1Y 9Q3', 1),
(129, 'N2M 4C2', 2),
(130, 'H9Z 5L8', 4),
(131, 'O7N 5Y4', 1),
(132, 'R7Q 6O9', 2),
(133, 'S2J 5O7', 1),
(134, 'H8S 4M6', 2),
(135, 'W0Z 4M1', 3),
(136, 'E0B 7H8', 3),
(137, 'X0E 0L3', 4),
(138, 'X4S 3W6', 1),
(139, 'K7P 8K4', 1),
(140, 'K3Q 6J6', 1),
(141, 'G9R 8T9', 1),
(142, 'Z9M 2T4', 1),
(143, 'M8F 7E9', 1),
(144, 'Y9T 4J0', 1),
(145, 'T5X 1I2', 1),
(146, 'K1L 2T0', 1),
(147, 'G2O 6I1', 3),
(148, 'D1G 4H1', 3),
(149, 'R5S 2B3', 3),
(150, 'U6E 2E3', 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ezy_Aircraft`
--
ALTER TABLE `ezy_Aircraft`
  ADD PRIMARY KEY (`AircraftID`),
  ADD KEY `FK_AircraftTypeID` (`AircraftTypeID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ezy_Aircraft`
--
ALTER TABLE `ezy_Aircraft`
  MODIFY `AircraftID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=151;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ezy_Aircraft`
--
ALTER TABLE `ezy_Aircraft`
  ADD CONSTRAINT `FK_AircraftTypeID` FOREIGN KEY (`AircraftTypeID`) REFERENCES `ezy_AircraftType` (`AircraftTypeID`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
