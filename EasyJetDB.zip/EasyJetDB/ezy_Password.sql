-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 14, 2019 at 12:59 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drice21`
--

-- --------------------------------------------------------

--
-- Table structure for table `ezy_Password`
--

CREATE TABLE `ezy_Password` (
  `PasswordID` int(11) NOT NULL,
  `CustomerID` int(11) NOT NULL,
  `Password` varbinary(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ezy_Password`
--

INSERT INTO `ezy_Password` (`PasswordID`, `CustomerID`, `Password`) VALUES
(22, 98, 0x9cbdeef8cf8571da6044714fbd4b8f2f),
(23, 15, 0x65b9be365f8641197abae36e6918a286),
(24, 30, 0x7fae62002701fe360543c32e3d3e65f7),
(25, 28, 0x253326614a2a029faa57da1e729a903d),
(26, 35, 0x080a9da73bc6fc6fa65d9b8c0086f1e7),
(27, 34, 0x8a81706e2600c5601dfb5d1a13e29fb1),
(28, 38, 0x3fcafe698b22e55add90e1aeff928137),
(29, 16, 0xbaf390da87ea8052cd03a34aef6c8df5),
(30, 18, 0xe99624d1dc7a543a2024ce21c550bde7),
(31, 37, 0x84499431e5cc33430e61334baa6e4461),
(32, 75, 0x2c715b289528a9f9e6676de276dd574c),
(33, 41, 0x451c4fb884c0f0502b1dcbcca66648a0),
(34, 73, 0x478bb0aa4f70b07b00602476f76e0ea9),
(35, 74, 0x9d1e41c76fb1faa8e6541b9f2af69390),
(36, 32, 0x79c617dba7f144d684b50172e720f69a),
(37, 29, 0x855a8112dac50542571b231dbb0423a8),
(38, 36, 0x0829a9be0da5a94c533250ec1d7eca1a),
(39, 99, 0xfa319c2fd51ad8e74a1cbfd28d8c3230),
(40, 33, 0x7998d11673966376b553b248810c5e2f),
(41, 20, 0x69d0ac8420ebe1839a7019b91723d4ab),
(42, 100, 0xc1f521b43a4805a603d04f0481d434ab),
(43, 19, 0x67012cb27fabec1f575ddf7e0f8218b0),
(44, 21, 0xb7419216b734961314d073631de7bd7c),
(45, 40, 0x59deef4d169fbf1d604183c26a3009da),
(46, 31, 0xbf439ab48cf970cc67aab1b26f4de13a),
(47, 27, 0xcbf00751dd2383dea41d24907764240a),
(48, 26, 0x34a51727dd8aef58b85ea00d4ba60892),
(49, 17, 0x344efd7c358f424b6fabcf93e4daa1f4),
(50, 39, 0xbf309a0480a82613512f534a9e1f89d6),
(51, 101, 0x60d76b6584cbe6954ab706ac391e2739),
(52, 102, 0x350684eaa4442297f82a823079f861e2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ezy_Password`
--
ALTER TABLE `ezy_Password`
  ADD PRIMARY KEY (`PasswordID`),
  ADD KEY `FK_CustomerID` (`CustomerID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ezy_Password`
--
ALTER TABLE `ezy_Password`
  MODIFY `PasswordID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ezy_Password`
--
ALTER TABLE `ezy_Password`
  ADD CONSTRAINT `FK_CustomerID` FOREIGN KEY (`CustomerID`) REFERENCES `ezy_Customers` (`CustomerID`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
