-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 14, 2019 at 12:58 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drice21`
--

-- --------------------------------------------------------

--
-- Table structure for table `ezy_InDemandFlight`
--

CREATE TABLE `ezy_InDemandFlight` (
  `InDemandFlightID` int(11) NOT NULL,
  `InDemandFlightAddFee` decimal(6,2) NOT NULL,
  `FlightID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ezy_InDemandFlight`
--

INSERT INTO `ezy_InDemandFlight` (`InDemandFlightID`, `InDemandFlightAddFee`, `FlightID`) VALUES
(2, '46.00', 45),
(4, '43.00', 64),
(6, '38.00', 10),
(7, '12.00', 28),
(8, '17.00', 84),
(9, '37.00', 69),
(10, '44.00', 72),
(11, '14.00', 92),
(12, '45.00', 21),
(13, '25.00', 94),
(14, '49.00', 58),
(15, '33.00', 35),
(16, '26.00', 56),
(17, '31.00', 55),
(18, '33.00', 46),
(19, '30.00', 99),
(20, '23.00', 34),
(21, '50.00', 84),
(22, '21.00', 15),
(23, '40.00', 50),
(24, '21.00', 86),
(25, '35.00', 24),
(26, '72.63', 18),
(27, '41.57', 12);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ezy_InDemandFlight`
--
ALTER TABLE `ezy_InDemandFlight`
  ADD PRIMARY KEY (`InDemandFlightID`),
  ADD KEY `FK_FlightIDTOInDemandFlight` (`FlightID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ezy_InDemandFlight`
--
ALTER TABLE `ezy_InDemandFlight`
  MODIFY `InDemandFlightID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ezy_InDemandFlight`
--
ALTER TABLE `ezy_InDemandFlight`
  ADD CONSTRAINT `FK_FlightIDTOInDemandFlight` FOREIGN KEY (`FlightID`) REFERENCES `ezy_Flight` (`FlightID`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
