-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 14, 2019 at 12:58 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drice21`
--

-- --------------------------------------------------------

--
-- Table structure for table `ezy_Flight`
--

CREATE TABLE `ezy_Flight` (
  `FlightID` int(11) NOT NULL,
  `FlightNo` varchar(255) NOT NULL,
  `ScheduleID` int(11) NOT NULL,
  `StatusID` int(11) NOT NULL,
  `AircraftID` int(11) NOT NULL,
  `FlightBasePriceGBP` decimal(6,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ezy_Flight`
--

INSERT INTO `ezy_Flight` (`FlightID`, `FlightNo`, `ScheduleID`, `StatusID`, `AircraftID`, `FlightBasePriceGBP`) VALUES
(1, ' ezy123', 2173, 3, 117, '23.00'),
(3, ' ezy111', 2246, 2, 103, '95.00'),
(4, ' ezy112', 2260, 1, 102, '130.00'),
(5, ' ezy113', 2206, 2, 149, '79.00'),
(6, ' ezy114', 2251, 1, 108, '111.00'),
(7, ' ezy115', 2258, 3, 131, '50.00'),
(8, ' ezy116', 2191, 2, 122, '20.00'),
(10, ' ezy118', 2205, 3, 109, '23.00'),
(11, ' ezy119', 2174, 1, 122, '25.00'),
(12, ' ezy120', 2176, 3, 142, '32.00'),
(13, ' ezy121', 2212, 3, 135, '94.00'),
(14, ' ezy122', 2203, 3, 128, '67.00'),
(15, ' ezy211', 2198, 3, 120, '110.00'),
(17, ' ezy125', 2204, 1, 143, '94.00'),
(18, ' ezy126', 2177, 3, 144, '32.00'),
(19, ' ezy127', 2265, 3, 110, '23.00'),
(20, ' ezy128', 2222, 3, 119, '144.00'),
(22, ' ezy130', 2197, 3, 122, '42.00'),
(23, ' ezy131', 2210, 3, 103, '79.00'),
(24, ' ezy132', 2261, 1, 115, '114.00'),
(25, ' ezy133', 2266, 1, 120, '109.00'),
(26, ' ezy134', 2211, 3, 102, '15.00'),
(27, ' ezy135', 2220, 3, 111, '148.00'),
(29, ' ezy137', 2233, 1, 138, '27.00'),
(30, ' ezy138', 2221, 3, 142, '81.00'),
(31, ' ezy139', 2201, 1, 101, '112.00'),
(32, ' ezy140', 2269, 3, 130, '136.00'),
(33, ' ezy141', 2264, 2, 137, '65.00'),
(34, ' ezy142', 2224, 3, 125, '143.00'),
(36, ' ezy144', 2252, 3, 121, '47.00'),
(38, ' ezy146', 2245, 3, 108, '97.00'),
(39, ' ezy147', 2231, 2, 142, '146.00'),
(40, ' ezy148', 2263, 2, 131, '127.00'),
(41, ' ezy149', 2216, 1, 104, '83.00'),
(42, ' ezy150', 2226, 1, 112, '75.00'),
(43, ' ezy151', 2183, 1, 121, '72.00'),
(44, ' ezy152', 2236, 1, 133, '15.00'),
(45, ' ezy153', 2215, 1, 103, '75.00'),
(48, ' ezy156', 2217, 2, 115, '113.00'),
(49, ' ezy157', 2232, 2, 109, '95.00'),
(51, ' ezy159', 2192, 1, 110, '30.00'),
(52, ' ezy160', 2175, 2, 109, '80.00'),
(53, ' ezy161', 2257, 1, 110, '33.00'),
(55, ' ezy163', 2253, 1, 133, '35.00'),
(56, ' ezy164', 2184, 2, 130, '91.00'),
(57, ' ezy165', 2227, 1, 121, '20.00'),
(61, ' ezy169', 2189, 2, 104, '45.00'),
(63, ' ezy171', 2250, 1, 101, '18.00'),
(64, ' ezy172', 2248, 3, 140, '15.00'),
(66, ' ezy174', 2262, 1, 114, '42.00'),
(67, ' ezy175', 2259, 2, 116, '35.00'),
(69, ' ezy177', 2240, 2, 143, '135.00'),
(72, ' ezy180', 2218, 1, 149, '124.00'),
(74, ' ezy182', 2247, 3, 129, '39.00'),
(75, ' ezy183', 2200, 2, 147, '48.00'),
(78, ' ezy186', 2219, 2, 130, '94.00'),
(79, ' ezy187', 2234, 1, 116, '121.00'),
(82, ' ezy190', 2193, 2, 110, '60.00'),
(83, ' ezy191', 2254, 3, 127, '149.00'),
(84, ' ezy192', 2186, 1, 128, '15.00'),
(89, ' ezy197', 2228, 2, 138, '91.00'),
(94, ' ezy202', 2256, 1, 124, '110.00'),
(95, ' ezy203', 2213, 3, 138, '85.00'),
(96, ' ezy204', 2223, 1, 134, '84.00'),
(99, ' ezy207', 2209, 1, 123, '24.00'),
(100, ' ezy208', 2230, 3, 117, '15.00'),
(101, ' ezy209', 2195, 3, 114, '79.00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ezy_Flight`
--
ALTER TABLE `ezy_Flight`
  ADD PRIMARY KEY (`FlightID`),
  ADD KEY `FK_ScheduleToFlight` (`ScheduleID`),
  ADD KEY `FK_FlightStatus` (`StatusID`),
  ADD KEY `FK_AircraftIDtoFlight` (`AircraftID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ezy_Flight`
--
ALTER TABLE `ezy_Flight`
  MODIFY `FlightID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ezy_Flight`
--
ALTER TABLE `ezy_Flight`
  ADD CONSTRAINT `FK_AircraftIDtoFlight` FOREIGN KEY (`AircraftID`) REFERENCES `ezy_Aircraft` (`AircraftID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_FlightStatus` FOREIGN KEY (`StatusID`) REFERENCES `ezy_Status` (`StatusID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_ScheduleToFlight` FOREIGN KEY (`ScheduleID`) REFERENCES `ezy_Schedule` (`ScheduleID`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
