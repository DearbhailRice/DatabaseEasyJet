-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 14, 2019 at 12:58 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drice21`
--

-- --------------------------------------------------------

--
-- Table structure for table `ezy_CheckIn`
--

CREATE TABLE `ezy_CheckIn` (
  `CheckInID` int(11) NOT NULL,
  `FlightID` int(11) NOT NULL,
  `PassangerID` int(11) NOT NULL,
  `CheckInStatusID` int(11) NOT NULL,
  `TransactionID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ezy_CheckIn`
--

INSERT INTO `ezy_CheckIn` (`CheckInID`, `FlightID`, `PassangerID`, `CheckInStatusID`, `TransactionID`) VALUES
(8, 40, 75, 2, 46),
(12, 72, 22, 2, 9),
(16, 72, 51, 2, 89),
(17, 48, 9, 2, 39),
(19, 40, 60, 2, 11),
(21, 48, 20, 2, 63),
(32, 43, 58, 2, 79),
(44, 23, 24, 2, 57),
(51, 49, 62, 2, 70),
(55, 31, 49, 2, 11),
(62, 72, 79, 2, 83),
(64, 38, 67, 2, 13),
(69, 61, 74, 2, 72),
(72, 96, 81, 2, 29),
(78, 49, 86, 2, 10),
(79, 52, 35, 2, 68),
(82, 61, 59, 2, 13),
(83, 94, 5, 2, 40),
(92, 84, 82, 2, 80),
(100, 66, 53, 2, 38);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ezy_CheckIn`
--
ALTER TABLE `ezy_CheckIn`
  ADD PRIMARY KEY (`CheckInID`),
  ADD KEY `FK_CheckInStatus` (`CheckInStatusID`),
  ADD KEY `FK_Flight` (`FlightID`),
  ADD KEY `FK_PassangerIDToCheckin` (`PassangerID`),
  ADD KEY `FK_Transaction` (`TransactionID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ezy_CheckIn`
--
ALTER TABLE `ezy_CheckIn`
  MODIFY `CheckInID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ezy_CheckIn`
--
ALTER TABLE `ezy_CheckIn`
  ADD CONSTRAINT `FK_CheckInStatus` FOREIGN KEY (`CheckInStatusID`) REFERENCES `ezy_CheckInStatus` (`CheckInStatusID`),
  ADD CONSTRAINT `FK_Flight` FOREIGN KEY (`FlightID`) REFERENCES `ezy_Flight` (`FlightID`),
  ADD CONSTRAINT `FK_PassangerIDToCheckin` FOREIGN KEY (`PassangerID`) REFERENCES `ezy_Passanger` (`PassangerID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_Transaction` FOREIGN KEY (`TransactionID`) REFERENCES `ezy_Transaction` (`TransactionID`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
