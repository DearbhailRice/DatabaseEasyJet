-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 14, 2019 at 12:59 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drice21`
--

-- --------------------------------------------------------

--
-- Table structure for table `ezy_SeatMap`
--

CREATE TABLE `ezy_SeatMap` (
  `SeatMapID` int(11) NOT NULL,
  `AircraftTypeID` int(11) NOT NULL,
  `RowNumberID` int(11) NOT NULL,
  `SeatLetterID` int(11) NOT NULL,
  `SeatTypeID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ezy_SeatMap`
--

INSERT INTO `ezy_SeatMap` (`SeatMapID`, `AircraftTypeID`, `RowNumberID`, `SeatLetterID`, `SeatTypeID`) VALUES
(151, 1, 1, 1, 1),
(152, 1, 1, 2, 1),
(153, 1, 1, 3, 1),
(154, 1, 1, 4, 1),
(155, 1, 1, 5, 1),
(156, 1, 1, 6, 1),
(163, 1, 2, 1, 2),
(164, 1, 2, 2, 2),
(165, 1, 2, 3, 2),
(166, 1, 2, 4, 2),
(167, 1, 2, 5, 2),
(168, 1, 2, 6, 2),
(169, 1, 3, 1, 2),
(170, 1, 3, 2, 2),
(171, 1, 3, 3, 2),
(172, 1, 3, 4, 2),
(173, 1, 3, 5, 2),
(174, 1, 3, 6, 2),
(175, 1, 4, 1, 3),
(176, 1, 4, 2, 3),
(177, 1, 4, 3, 3),
(178, 1, 4, 4, 3),
(179, 1, 4, 5, 3),
(180, 1, 4, 6, 3),
(181, 1, 5, 1, 3),
(182, 1, 5, 2, 3),
(183, 1, 5, 3, 3),
(184, 1, 5, 4, 3),
(185, 1, 5, 5, 3),
(186, 1, 5, 6, 3),
(207, 2, 1, 1, 1),
(208, 2, 1, 2, 1),
(209, 2, 1, 3, 1),
(210, 2, 1, 4, 1),
(211, 2, 1, 5, 1),
(212, 2, 1, 6, 1),
(213, 2, 2, 1, 2),
(214, 2, 2, 2, 2),
(215, 2, 2, 3, 2),
(216, 2, 2, 4, 2),
(217, 2, 2, 5, 2),
(218, 2, 2, 6, 2),
(219, 2, 3, 1, 2),
(220, 2, 3, 2, 2),
(221, 2, 3, 3, 2),
(222, 2, 3, 4, 2),
(223, 2, 3, 5, 2),
(224, 2, 3, 6, 2),
(225, 2, 4, 1, 3),
(226, 2, 4, 2, 3),
(227, 2, 4, 3, 3),
(228, 2, 4, 4, 3),
(229, 2, 4, 5, 3),
(230, 2, 4, 6, 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ezy_SeatMap`
--
ALTER TABLE `ezy_SeatMap`
  ADD PRIMARY KEY (`SeatMapID`),
  ADD KEY `Fk_RowNumber` (`RowNumberID`),
  ADD KEY `FK_SeatLetter` (`SeatLetterID`),
  ADD KEY `FK_SeatTypeID` (`SeatTypeID`),
  ADD KEY `FK_AircraftType` (`AircraftTypeID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ezy_SeatMap`
--
ALTER TABLE `ezy_SeatMap`
  MODIFY `SeatMapID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=231;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ezy_SeatMap`
--
ALTER TABLE `ezy_SeatMap`
  ADD CONSTRAINT `FK_AircraftType` FOREIGN KEY (`AircraftTypeID`) REFERENCES `ezy_AircraftType` (`AircraftTypeID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_SeatLetter` FOREIGN KEY (`SeatLetterID`) REFERENCES `ezy_SeatLetter` (`SeatLetterID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_SeatTypeID` FOREIGN KEY (`SeatTypeID`) REFERENCES `ezy_SeatType` (`SeatTypeID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `Fk_RowNumber` FOREIGN KEY (`RowNumberID`) REFERENCES `ezy_RowNumber` (`RownumberID`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
