-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 14, 2019 at 12:58 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drice21`
--

-- --------------------------------------------------------

--
-- Table structure for table `ezy_EJ+MembershipCard`
--

CREATE TABLE `ezy_EJ+MembershipCard` (
  `EJ+MembershipCardID` int(11) NOT NULL,
  `EJ+MembershipCardNumber` varchar(255) NOT NULL,
  `EJ+membershipTypeID` int(11) NOT NULL,
  `EJ+ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ezy_EJ+MembershipCard`
--

INSERT INTO `ezy_EJ+MembershipCard` (`EJ+MembershipCardID`, `EJ+MembershipCardNumber`, `EJ+membershipTypeID`, `EJ+ID`) VALUES
(11, '40292756070819', 2, 27),
(12, '51668579623010', 1, 28),
(13, '50794345537764', 1, 29),
(14, '71819473249555', 2, 30),
(15, '82959140840080', 3, 31),
(16, '8456303085202', 3, 32),
(17, '79955920936955', 1, 33),
(18, '62912104503655', 3, 34),
(19, '94593704916069', 2, 35),
(20, '51241060500596', 1, 36),
(21, '31605931614722', 1, 37),
(22, '86192877560967', 1, 38),
(23, '32822485003866', 2, 39),
(24, '82952956609855', 1, 40),
(25, '9231232237373', 2, 41),
(42, '13888168749683', 4, 27),
(43, '88673384991877', 4, 28),
(44, '46456216268235', 4, 29),
(45, '47685124767929', 4, 30),
(46, '35264921214277', 4, 31),
(47, '1400547287344', 4, 32),
(48, '95370050676748', 4, 33),
(49, '14842426567756', 4, 34),
(50, '93890048339537', 4, 35),
(51, '16398143119275', 4, 36),
(52, '54056023545420', 4, 37),
(53, '40127905951811', 4, 38),
(54, '64288039736532', 4, 39),
(55, '86621565355685', 4, 40),
(56, '31181949795662', 4, 41);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ezy_EJ+MembershipCard`
--
ALTER TABLE `ezy_EJ+MembershipCard`
  ADD PRIMARY KEY (`EJ+MembershipCardID`),
  ADD KEY `FK_EJ+ID` (`EJ+ID`),
  ADD KEY `FK_EJ+MembershipType` (`EJ+membershipTypeID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ezy_EJ+MembershipCard`
--
ALTER TABLE `ezy_EJ+MembershipCard`
  MODIFY `EJ+MembershipCardID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ezy_EJ+MembershipCard`
--
ALTER TABLE `ezy_EJ+MembershipCard`
  ADD CONSTRAINT `FK_EJ+ID` FOREIGN KEY (`EJ+ID`) REFERENCES `ezy_EJ+` (`EJ+ID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_EJ+MembershipType` FOREIGN KEY (`EJ+membershipTypeID`) REFERENCES `ezy_EJ+MembershipType` (`EJ+MembershipTypeID`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
