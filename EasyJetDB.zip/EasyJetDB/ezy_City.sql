-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 14, 2019 at 12:58 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drice21`
--

-- --------------------------------------------------------

--
-- Table structure for table `ezy_City`
--

CREATE TABLE `ezy_City` (
  `CityID` int(11) NOT NULL,
  `CityName` varchar(255) NOT NULL,
  `CountryID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ezy_City`
--

INSERT INTO `ezy_City` (`CityID`, `CityName`, `CountryID`) VALUES
(24, 'Alicante', 57),
(25, 'Amsterdam', 34),
(26, 'Barcelona', 57),
(27, 'Birmingham', 62),
(28, 'Bordeaux', 19),
(29, 'Bristol', 62),
(30, 'Canary Island', 56),
(31, 'central Scotland', 60),
(32, 'Dubrovnik', 53),
(33, 'Edinburgh', 60),
(34, 'Faro', 56),
(35, 'Geneva', 5),
(36, 'Glasgow', 60),
(37, 'Ibiza', 56),
(38, 'Isle Of Man', 59),
(39, 'Jersey', 59),
(40, 'Krakow', 55),
(41, 'Liverpool', 62),
(42, 'London', 62),
(43, 'Lyon', 19),
(44, 'Majorca Palma', 56),
(45, 'Malaga', 57),
(46, 'Naples', 54),
(47, 'Newcastle', 62),
(48, 'Nice', 19),
(49, 'Paris', 19),
(50, 'Prague', 12),
(51, 'Reykjavik Keflavik', 24),
(52, 'Salzburg', 52),
(53, 'Split', 53),
(54, 'Valencia', 57),
(55, 'Venice', 54),
(56, 'Belfast', 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ezy_City`
--
ALTER TABLE `ezy_City`
  ADD PRIMARY KEY (`CityID`),
  ADD KEY `FK_CountryToCity` (`CountryID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ezy_City`
--
ALTER TABLE `ezy_City`
  MODIFY `CityID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ezy_City`
--
ALTER TABLE `ezy_City`
  ADD CONSTRAINT `FK_CountryToCity` FOREIGN KEY (`CountryID`) REFERENCES `ezy_Country` (`CountryID`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
