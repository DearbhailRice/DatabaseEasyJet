-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 14, 2019 at 12:58 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drice21`
--

-- --------------------------------------------------------

--
-- Table structure for table `ezy_ContactTelNum`
--

CREATE TABLE `ezy_ContactTelNum` (
  `ContactTelNumID` int(11) NOT NULL,
  `CountryTelCodeID` int(11) NOT NULL,
  `ContactNum` varchar(255) NOT NULL,
  `CustomerID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ezy_ContactTelNum`
--

INSERT INTO `ezy_ContactTelNum` (`ContactTelNumID`, `CountryTelCodeID`, `ContactNum`, `CustomerID`) VALUES
(2, 34, '4396390', 21),
(3, 8, '12382359851', 11),
(9, 6, '13815623259', 20),
(11, 46, '7429794', 28),
(12, 12, '18611033968', 11),
(14, 41, '2466561', 20),
(15, 14, '4018929', 19),
(18, 11, '11422336293', 30),
(19, 35, '18336287191', 29),
(20, 1, '12988914740', 25),
(23, 9, '12849049006', 20),
(24, 28, '18383040125', 25),
(27, 46, '14234955912', 18),
(28, 24, '9235735', 29),
(29, 29, '12737133514', 18),
(32, 5, '8281571', 15),
(34, 20, '2462299', 30),
(35, 29, '11783202210', 27),
(36, 32, '7743203', 27),
(37, 16, '13674625616', 30),
(42, 46, '19747173434', 28),
(43, 31, '1906316', 26),
(44, 36, '17423661837', 20),
(48, 37, '9929495', 16),
(49, 36, '6234027', 27),
(50, 37, '6257986', 20),
(52, 44, '6677237', 27),
(60, 48, '6969422', 28),
(65, 34, '6134183', 25),
(66, 24, '14483066481', 26),
(69, 29, '12331531341', 30),
(73, 2, '14665782794', 16),
(74, 41, '5884083', 15),
(75, 30, '13568899747', 26),
(77, 15, '5220321', 30),
(79, 3, '11101706462', 18),
(80, 14, '9404040', 17),
(82, 19, '3348291', 19),
(84, 28, '11839375400', 25),
(87, 28, '1241637', 25),
(89, 4, '7360778', 26),
(96, 34, '1282630', 16),
(102, 1, '123456789', 102);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ezy_ContactTelNum`
--
ALTER TABLE `ezy_ContactTelNum`
  ADD PRIMARY KEY (`ContactTelNumID`),
  ADD KEY `FK_CountryTelCodeID` (`CountryTelCodeID`),
  ADD KEY `FK_CustomerIDContactTel` (`CustomerID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ezy_ContactTelNum`
--
ALTER TABLE `ezy_ContactTelNum`
  MODIFY `ContactTelNumID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ezy_ContactTelNum`
--
ALTER TABLE `ezy_ContactTelNum`
  ADD CONSTRAINT `FK_CountryTelCodeID` FOREIGN KEY (`CountryTelCodeID`) REFERENCES `ezy_CountryTelCode` (`CountryTelCodeID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CustomerIDContactTel` FOREIGN KEY (`CustomerID`) REFERENCES `ezy_Customers` (`CustomerID`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
