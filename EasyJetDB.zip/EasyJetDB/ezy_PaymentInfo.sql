-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 14, 2019 at 12:59 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drice21`
--

-- --------------------------------------------------------

--
-- Table structure for table `ezy_PaymentInfo`
--

CREATE TABLE `ezy_PaymentInfo` (
  `PaymentInfoID` int(11) NOT NULL,
  `CardTypeID` int(11) NOT NULL,
  `CardHoldersName` varchar(255) NOT NULL,
  `CardNumber` varbinary(255) NOT NULL,
  `CardExpiryID` int(11) NOT NULL,
  `CustomerID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ezy_PaymentInfo`
--

INSERT INTO `ezy_PaymentInfo` (`PaymentInfoID`, `CardTypeID`, `CardHoldersName`, `CardNumber`, `CardExpiryID`, `CustomerID`) VALUES
(1, 3, 'Hashim Bray', 0x37ae7e6341699a3bd5f51e1cef9f7dd4, 4, 98),
(2, 1, 'Maggie Serrano', 0x7da915ba0c6f2deab160ad51ea9ffefdc47af0539e5281376727cf0893aa3d2c, 2, 15),
(3, 3, 'Kelsey George', 0x58a9cbed65e45a34dbc7625477beb302c8f47afe860657ac9ba6e2c0ccedcca7, 1, 30),
(4, 9, 'Phyllis Mcneil', 0xd71bb3ae60b5da86514bc341ee2f8c75, 5, 28),
(5, 2, 'Genevieve Bolton', 0xa97e9801fe09e50e072b6f4b8e78813e0bbff5fdee8ef1ff79a16e351dee1333, 4, 35),
(6, 4, 'Alma Mendoza', 0xa0ec5d692955a992f3d9eb208a70cf3fa161129342bcf0a68a4e749c1e49ae85, 10, 34),
(7, 9, 'Simon Sutton', 0x6d88a60c5c840f7e92feed68f1ce71be526467d146c581e26b9a127c90f6745c, 7, 38),
(8, 3, 'Drake Solis', 0x611d96695b496112f79db95cd455ae85, 3, 16),
(9, 7, 'Farrah Moran', 0x38cdcfd9bca1332572de706316489b4dd6c6f52bf7ac9840bde76e7a2dfb02c7, 1, 18),
(10, 4, 'Tanek Underwood', 0xc9f61eb504a08d3d63f4eda497899beb20a49eb4369bfb5fc63c96291e765a39, 4, 37),
(11, 6, 'Vanna Norris', 0xcab5d04c603e5cfd0db3f040771e74a60966afed014ff1d620cd392a6b45da76, 5, 75),
(12, 8, 'Beau Suarez', 0x5769ef8daedb3b157cbc991919afb04b36f02ccf923f57e2237a92a768e9de26, 1, 41),
(13, 7, 'Lunea Arnold', 0x8b4f0ec6ee05d521423df97601021a49, 10, 73),
(14, 8, 'Hayley Bolton', 0xba95ad4b1eda27f2ebf060ae69dcd5d6efb8b9c1cab205296d41919718e652df, 9, 74),
(15, 10, 'Stephen David', 0x6f400e55477b5a035cbbb5cadd8dc8a633b1906a7b2f8f22e2a457288531d9c5, 8, 32),
(16, 8, 'Owen Walton', 0x9935beb56972043856ca515a24a91b5ba41c933f669b43aeea7b9d06c5812864, 3, 29),
(17, 4, 'Tyler Compton', 0x34b75f7347a225d2d3fe1fd6c47f4b4bb10581139228fc4413367e969ad1b361, 7, 36),
(18, 2, 'Donovan Lambert', 0x714ea11a2c9be9320a9ef91a3c7ada99980db5ab16dd759e0b1b430b62768ce0, 9, 99),
(19, 1, 'Olga Nielsen', 0x18887901bd6af108610a835a421b86a49207a439059dceffc8160f54291d6fb4, 5, 33),
(20, 5, 'Arthur Cooper', 0x9c5e1b4f48587394cd047ea391292579, 2, 20),
(21, 10, 'Louis Guerrero', 0x9f1ff087b4cda2bb06bed5a1c51e20dd718b5ffdc0e57f826690187096b7b8c0, 6, 100),
(22, 2, 'Carlos Wong', 0x35c37e19e532897746e5994b73ef1fb8c8f47afe860657ac9ba6e2c0ccedcca7, 10, 19),
(23, 3, 'Stewart Blankenship', 0xa29c82871460b57548d527d53c674f60fba31e6c5aa536b07b075c4143743db2, 4, 21),
(24, 4, 'Seth Tucker', 0x8298d46eee8600926383d88b8b50823ddee3c5b8a911b0261431a39afa1a90ff, 7, 11),
(25, 2, 'Tallulah Stein', 0xa7c1738dfdf2d5b83ca37db5af337d45ef7ff1161db821fbb51f96587101f7c1, 2, 40),
(26, 9, 'Justina Brown', 0x160eec5fac108c605a7065db911b61ad95500fa5c4d5235efba3d9677a189e1a, 6, 31),
(27, 4, 'Martina Wong', 0xc498d1f6fd4250475d4148d8e1c4e4a5e0e79c185401d03d50d3933d382c27ef, 3, 27),
(28, 5, 'Geraldine Hunt', 0x43007c46375712fcd0fd7ac3ca73f0ee9a1fee8b5801b49444ba2667457dbc28, 4, 26),
(29, 7, 'Yvonne Warner', 0xab5eda73e65251551346483247128219faa9493b9dd495053c520c3fb54085df, 3, 17),
(30, 6, 'Marny Potter', 0x67c6a6bcc346e63d777591a6118a5d9c58b680e5ced9d2e5ac5ff9408b84ef37, 6, 39),
(32, 6, 'Harleen Frances Quinzel', 0x3bb5e860ac97ca00e906e589cc213aac, 26, 102);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ezy_PaymentInfo`
--
ALTER TABLE `ezy_PaymentInfo`
  ADD PRIMARY KEY (`PaymentInfoID`),
  ADD KEY `FK_CardExpiration` (`CardExpiryID`),
  ADD KEY `FK_CardType` (`CardTypeID`),
  ADD KEY `FK_CustomerToPayment` (`CustomerID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ezy_PaymentInfo`
--
ALTER TABLE `ezy_PaymentInfo`
  MODIFY `PaymentInfoID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ezy_PaymentInfo`
--
ALTER TABLE `ezy_PaymentInfo`
  ADD CONSTRAINT `FK_CardExpiration` FOREIGN KEY (`CardExpiryID`) REFERENCES `ezy_CardExpiry` (`CardExpiryID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CardType` FOREIGN KEY (`CardTypeID`) REFERENCES `ezy_CardType` (`CardTypeID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CustomerToPayment` FOREIGN KEY (`CustomerID`) REFERENCES `ezy_Customers` (`CustomerID`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
