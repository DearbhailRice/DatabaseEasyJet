-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 14, 2019 at 12:58 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drice21`
--

-- --------------------------------------------------------

--
-- Table structure for table `ezy_Customers`
--

CREATE TABLE `ezy_Customers` (
  `CustomerID` int(11) NOT NULL,
  `TitleID` int(11) DEFAULT NULL,
  `FirstName` varchar(255) NOT NULL,
  `LastName` varchar(255) NOT NULL,
  `EmailAddress` varchar(255) NOT NULL,
  `AddressID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ezy_Customers`
--

INSERT INTO `ezy_Customers` (`CustomerID`, `TitleID`, `FirstName`, `LastName`, `EmailAddress`, `AddressID`) VALUES
(11, 3, 'Roth', 'Mullins', 'sem.elit@arcuVestibulum.net', 33),
(15, 1, 'Cooper', 'Bowman', 'metus@metusAliquam.edu', 2),
(16, 3, 'Naomi', 'Donaldson', 'imperdiet.dictum@orci.org', 10),
(17, 4, 'Gail', 'Fernandez', 'amet.consectetuer@quis.net', 34),
(18, 2, 'Alexis', 'Drake', 'Donec.non@molestie.net', 10),
(19, 1, 'Ryan', 'Mejia', 'dis.parturient@eget.org', 31),
(20, 4, 'Karyn', 'Herman', 'ipsum@Aliquamnec.ca', 28),
(21, 3, 'Denise', 'Elliott', 'Pellentesque.habitant@nonsollicitudina.ca', 31),
(25, 1, 'Chancellor', 'Robles', 'Nullam@augueeutellus.com', 1),
(26, 1, 'Alden', 'Joyce', 'posuere.vulputate.lacus@DonecfringillaDonec.edu', 34),
(27, 3, 'Rachel', 'Tyler', 'lorem.luctus.ut@fermentum.co.uk', 34),
(28, 1, 'Elvis', 'Sharp', 'volutpat.nunc@Sednuncest.com', 5),
(29, 1, 'Orlando', 'Waters', 'lectus.rutrum.urna@famesacturpis.ca', 17),
(30, 1, 'Lucian', 'Bond', 'Nam.ac@feugiatLoremipsum.co.uk', 2),
(31, 2, 'Maris', 'Hopper', 'cursus@Aeneaneget.com', 34),
(32, 3, 'Chloe', 'Osborn', 'magna@sitametrisus.edu', 16),
(33, 1, 'Cruz', 'Hamilton', 'vitae@molestie.edu', 25),
(34, 3, 'Scarlet', 'Patton', 'accumsan.neque.et@nonsollicitudin.com', 7),
(35, 1, 'Honorato', 'Riddle', 'augue.ac@dignissim.edu', 5),
(36, 2, 'Walker', 'Larsen', 'mauris.Morbi@semper.edu', 17),
(37, 3, 'Bree', 'Harrington', 'ornare.egestas@felis.com', 10),
(38, 3, 'Meredith', 'Burton', 'ipsum.Phasellus@sit.edu', 8),
(39, 3, 'Kelsey', 'Cote', 'vel.turpis@augueac.org', 33),
(40, 1, 'Alexis', 'Franco', 'Proin@congue.org', 34),
(41, 2, 'Aimee', 'Bray', 'Nulla@Nuncquis.net', 13),
(73, 1, 'Callie', 'Ochoa', 'lectus.a@nonummyacfeugiat.co.uk', 13),
(74, 4, 'Bianca', 'Hewitt', 'aliquam.arcu.Aliquam@orci.org', 14),
(75, 3, 'Asher', 'Pickett', 'eget@imperdietornare.co.uk', 10),
(98, 4, 'Cora', 'Moon', 'auctor@urnanec.co.uk', 1),
(99, 2, 'Denise', 'Lowery', 'non@morbitristiquesenectus.com', 24),
(100, 1, 'Maite', 'Ball', 'Mauris@auctor.net', 29),
(101, 1, 'Bruce', 'Wane', 'definetlynotbatman@gmail.com', 13),
(102, 3, 'Harley ', 'Quinn', 'daddyslittlemonster@dc.ac.uk', 37);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ezy_Customers`
--
ALTER TABLE `ezy_Customers`
  ADD PRIMARY KEY (`CustomerID`),
  ADD KEY `FK_AddressID` (`AddressID`),
  ADD KEY `FK_TitleID` (`TitleID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ezy_Customers`
--
ALTER TABLE `ezy_Customers`
  MODIFY `CustomerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ezy_Customers`
--
ALTER TABLE `ezy_Customers`
  ADD CONSTRAINT `FK_AddressID` FOREIGN KEY (`AddressID`) REFERENCES `ezy_Address` (`AddressID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_TitleID` FOREIGN KEY (`TitleID`) REFERENCES `ezy_Title` (`TitleID`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
