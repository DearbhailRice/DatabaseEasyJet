-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 14, 2019 at 12:56 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drice21`
--

-- --------------------------------------------------------

--
-- Table structure for table `ezy_Address`
--

CREATE TABLE `ezy_Address` (
  `AddressID` int(11) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `AddressLine2` varchar(255) DEFAULT NULL,
  `Town/City` varchar(255) NOT NULL,
  `Postcode/Zip` varchar(255) NOT NULL,
  `CountryID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ezy_Address`
--

INSERT INTO `ezy_Address` (`AddressID`, `Address`, `AddressLine2`, `Town/City`, `Postcode/Zip`, `CountryID`) VALUES
(1, '53 Lisburn Ave.', '', 'Belfast', 'BT9 7FX', 3),
(2, 'Ap #216-4398 Dapibus Street', NULL, 'Kortessem', '72065', 6),
(3, 'P.O. Box 104, 4045 At Rd.', NULL, 'Tolve', '50511', 11),
(4, '795-7467 Sed Av.', NULL, 'Aklavik', 'SS9 2BC', 20),
(5, '939-7712 Integer Street', NULL, 'Itabuna', '507760', 16),
(6, 'P.O. Box 727, 209 Orci Ave', NULL, 'Banff', '235911', 43),
(7, '2776 Dolor. St.', NULL, 'Rugby', '60916', 52),
(8, 'Ap #563-833 Lacus, Ave', NULL, 'Samsun', '312228', 17),
(9, 'Ap #344-5081 Sagittis Ave', NULL, 'Laakirchen', '21709', 50),
(10, '9634 Pellentesque Road', NULL, 'Namur', 'M2H 1S3', 3),
(11, 'P.O. Box 310, 3817 Nam Ave', NULL, 'San Demetrio Corone', '34411', 36),
(12, 'P.O. Box 721, 3279 Tellus Rd.', NULL, 'Brive-la-Gaillarde', '680615', 7),
(13, '297-474 Odio. Ave', NULL, 'Leuze', 'N4R 9B3', 33),
(14, 'P.O. Box 898, 779 Eleifend. Av.', NULL, 'Medicine Hat', '86091', 14),
(15, 'Ap #682-8407 Donec Rd.', NULL, 'Saint-G?ry', 'G5T 4H5', 39),
(16, '2347 Risus. Avenue', NULL, 'Bhatinda', '74985', 19),
(17, '5122 Magna. Av.', NULL, 'Tione di Trento', '7472', 19),
(18, 'P.O. Box 569, 4545 Nec Road', NULL, 'Victoria', '5175', 35),
(19, '421-112 In Ave', NULL, 'Falmouth', '64-118', 24),
(20, 'P.O. Box 898, 4162 Lectus St.', NULL, 'Mabompr?', '61121', 13),
(21, 'P.O. Box 221, 1958 Sed St.', NULL, 'Emmen', '564198', 22),
(22, 'P.O. Box 190, 3746 Sociis St.', NULL, 'Ramagundam', '33229', 22),
(23, '995-9799 Interdum. Ave', NULL, 'Louveign?', 'S7K 0E4', 52),
(24, 'Ap #675-7956 Sed Av.', NULL, 'Salisbury', '654278', 44),
(25, '3044 Turpis. Street', NULL, 'Baricella', '2487 OO', 58),
(26, 'Ap #488-1724 Nulla Ave', NULL, 'South Dum Dum', '705867', 16),
(27, 'P.O. Box 956, 7334 Ut Street', NULL, 'Stonewall', '586133', 53),
(28, '2169 Nec St.', NULL, 'Glovertown', '7799', 38),
(29, '185-9798 Urna. St.', NULL, 'Carluke', '27372', 20),
(30, '378-277 Duis St.', NULL, 'Bertogne', '10581-020', 39),
(31, '707-3602 Vel, Rd.', NULL, 'Saint-Pierre', '90052', 49),
(32, 'Ap #281-7655 Pretium Av.', NULL, 'Filot', '280615', 54),
(33, '185-9656 Pellentesque, Rd.', NULL, 'Campobasso', '5498 VL', 12),
(34, '7232 Amet Rd.', NULL, 'Forges', '669382', 57),
(35, 'Ap #925-3539 Vel Rd.', NULL, 'Springdale', '65662', 50),
(36, 'Ap #493-8141 Quis Street', NULL, 'Enines', '22651', 51),
(37, '101 arkham asylum', NULL, 'Gotham ', 'GOT 2KBM', 46);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ezy_Address`
--
ALTER TABLE `ezy_Address`
  ADD PRIMARY KEY (`AddressID`),
  ADD KEY `FK_CountryID` (`CountryID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ezy_Address`
--
ALTER TABLE `ezy_Address`
  MODIFY `AddressID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ezy_Address`
--
ALTER TABLE `ezy_Address`
  ADD CONSTRAINT `FK_CountryID` FOREIGN KEY (`CountryID`) REFERENCES `ezy_Country` (`CountryID`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
