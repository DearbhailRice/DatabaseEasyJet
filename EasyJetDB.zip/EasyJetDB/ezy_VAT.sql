-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 14, 2019 at 01:00 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drice21`
--

-- --------------------------------------------------------

--
-- Table structure for table `ezy_VAT`
--

CREATE TABLE `ezy_VAT` (
  `VATID` int(11) NOT NULL,
  `RouteID` int(11) NOT NULL,
  `VATPricinginGBP` decimal(6,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ezy_VAT`
--

INSERT INTO `ezy_VAT` (`VATID`, `RouteID`, `VATPricinginGBP`) VALUES
(1, 1, '3.50'),
(2, 2, '1.37'),
(3, 3, '50.00'),
(4, 4, '7.46'),
(5, 5, '7.46'),
(6, 6, '12.00'),
(7, 7, '6.50'),
(8, 8, '7.50'),
(9, 9, '15.30'),
(10, 10, '45.00'),
(11, 19, '0.98'),
(12, 20, '45.00'),
(13, 21, '2.00'),
(14, 22, '13.00'),
(15, 23, '75.00'),
(16, 24, '0.00'),
(17, 25, '0.00'),
(18, 26, '0.00'),
(19, 27, '10.50'),
(20, 28, '0.00'),
(21, 29, '12.50'),
(22, 30, '0.00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ezy_VAT`
--
ALTER TABLE `ezy_VAT`
  ADD PRIMARY KEY (`VATID`),
  ADD KEY `FK_RouteToVAT` (`RouteID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ezy_VAT`
--
ALTER TABLE `ezy_VAT`
  MODIFY `VATID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ezy_VAT`
--
ALTER TABLE `ezy_VAT`
  ADD CONSTRAINT `FK_RouteToVAT` FOREIGN KEY (`RouteID`) REFERENCES `ezy_Route` (`RouteID`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
