-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 14, 2019 at 12:58 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drice21`
--

-- --------------------------------------------------------

--
-- Table structure for table `ezy_EJ+`
--

CREATE TABLE `ezy_EJ+` (
  `EJ+ID` int(11) NOT NULL,
  `CustomerID` int(11) NOT NULL,
  `DateOfBirth` date NOT NULL,
  `CompanyName` varchar(255) DEFAULT NULL,
  `CountryOfDeliveryID` int(11) NOT NULL,
  `BillingAddressID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ezy_EJ+`
--

INSERT INTO `ezy_EJ+` (`EJ+ID`, `CustomerID`, `DateOfBirth`, `CompanyName`, `CountryOfDeliveryID`, `BillingAddressID`) VALUES
(27, 17, '1974-08-02', 'Molestie Tellus Aenean Foundation', 3, 6),
(28, 21, '1984-03-05', 'Scelerisque Sed Sapien Corp.', 3, 12),
(29, 100, '1932-08-29', 'Eu Institute', 5, 6),
(30, 19, '1958-06-02', 'Non Leo Vivamus Consulting', 7, 13),
(31, 27, '2018-01-28', 'Non Consulting', 7, 26),
(32, 37, '1938-11-11', 'Maecenas Malesuada LLC', 8, 10),
(33, 18, '1942-10-08', 'Velit Incorporated', 10, 34),
(34, 16, '2020-04-07', 'Enim Inc.', 11, 12),
(35, 28, '1990-04-29', 'Tristique Pharetra Company', 12, 13),
(36, 25, '1911-09-23', 'Fringilla Purus Institute', 15, 6),
(37, 11, '1989-11-15', 'Nibh Phasellus Nulla Inc.', 22, 16),
(38, 29, '1972-03-07', 'Proin Nisl LLP', 23, 22),
(39, 73, '1913-06-24', 'Semper LLP', 26, 27),
(40, 32, '1916-08-21', 'Velit Eget Laoreet Company', 28, 29),
(41, 30, '1919-12-14', 'Cras Eu Tellus Inc.', 31, 31),
(42, 15, '2006-10-07', 'Odio Nam Foundation', 32, 35),
(43, 40, '1976-06-23', 'At Iaculis Corp.', 38, 26),
(44, 34, '1972-05-11', 'Proin Inc.', 39, 16),
(45, 36, '1956-12-02', 'Ultrices Iaculis Odio Ltd', 40, 5),
(46, 20, '1917-06-24', 'Ac Arcu Nunc LLC', 44, 21),
(47, 41, '1923-05-18', 'Facilisis Eget Ltd', 44, 10),
(48, 98, '2007-12-25', 'Integer PC', 48, 25),
(49, 26, '1913-05-05', 'Arcu Vestibulum Inc.', 50, 24),
(50, 74, '1929-01-13', 'In Lorem Incorporated', 53, 30),
(51, 31, '1964-05-24', 'Massa Associates', 56, 13);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ezy_EJ+`
--
ALTER TABLE `ezy_EJ+`
  ADD PRIMARY KEY (`EJ+ID`),
  ADD KEY `FK_CustomerToEJ+` (`CustomerID`),
  ADD KEY `FK_CountryOfDelivery` (`CountryOfDeliveryID`),
  ADD KEY `FK_BillingAddress` (`BillingAddressID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ezy_EJ+`
--
ALTER TABLE `ezy_EJ+`
  MODIFY `EJ+ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ezy_EJ+`
--
ALTER TABLE `ezy_EJ+`
  ADD CONSTRAINT `FK_BillingAddress` FOREIGN KEY (`BillingAddressID`) REFERENCES `ezy_Address` (`AddressID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CountryOfDelivery` FOREIGN KEY (`CountryOfDeliveryID`) REFERENCES `ezy_Country` (`CountryID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CustomerToEJ+` FOREIGN KEY (`CustomerID`) REFERENCES `ezy_Customers` (`CustomerID`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
