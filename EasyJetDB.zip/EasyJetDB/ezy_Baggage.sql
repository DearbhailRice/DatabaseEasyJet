-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 14, 2019 at 12:57 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drice21`
--

-- --------------------------------------------------------

--
-- Table structure for table `ezy_Baggage`
--

CREATE TABLE `ezy_Baggage` (
  `BaggageID` int(11) NOT NULL,
  `BookingID` int(11) NOT NULL,
  `BaggageTypeID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ezy_Baggage`
--

INSERT INTO `ezy_Baggage` (`BaggageID`, `BookingID`, `BaggageTypeID`) VALUES
(2, 1, 7),
(3, 1, 4),
(4, 2, 8),
(5, 3, 11),
(6, 4, 10),
(7, 5, 13),
(8, 5, 4),
(9, 6, 6),
(10, 6, 13),
(11, 8, 6),
(12, 8, 2),
(13, 8, 10),
(14, 9, 14),
(15, 9, 12),
(16, 11, 7),
(17, 13, 3),
(18, 13, 7),
(19, 14, 2),
(20, 14, 12),
(21, 15, 3),
(22, 15, 4),
(23, 15, 13),
(24, 16, 1),
(25, 16, 14),
(26, 16, 7),
(27, 17, 7),
(28, 18, 4),
(29, 19, 6),
(30, 20, 1),
(31, 20, 9),
(32, 21, 14),
(33, 21, 13),
(34, 24, 13),
(35, 25, 14),
(102, 91, 1),
(103, 93, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ezy_Baggage`
--
ALTER TABLE `ezy_Baggage`
  ADD PRIMARY KEY (`BaggageID`),
  ADD KEY `FK_BookingIDToBaggage` (`BookingID`),
  ADD KEY `FK_BaggageTypeID` (`BaggageTypeID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ezy_Baggage`
--
ALTER TABLE `ezy_Baggage`
  MODIFY `BaggageID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ezy_Baggage`
--
ALTER TABLE `ezy_Baggage`
  ADD CONSTRAINT `FK_BaggageTypeID` FOREIGN KEY (`BaggageTypeID`) REFERENCES `ezy_BaggageType` (`BaggageTypeID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_BookingIDToBaggage` FOREIGN KEY (`BookingID`) REFERENCES `ezy_Booking` (`BookingID`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
