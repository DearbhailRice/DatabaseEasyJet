-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 14, 2019 at 12:57 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drice21`
--

-- --------------------------------------------------------

--
-- Table structure for table `ezy_CardExpiry`
--

CREATE TABLE `ezy_CardExpiry` (
  `CardExpiryID` int(11) NOT NULL,
  `CardExpiryMonthID` int(11) NOT NULL,
  `CardExpiryYearID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ezy_CardExpiry`
--

INSERT INTO `ezy_CardExpiry` (`CardExpiryID`, `CardExpiryMonthID`, `CardExpiryYearID`) VALUES
(1, 4, 1),
(2, 8, 1),
(3, 2, 1),
(4, 3, 1),
(5, 4, 1),
(6, 5, 1),
(7, 6, 1),
(8, 7, 1),
(9, 8, 1),
(10, 9, 1),
(11, 10, 1),
(12, 11, 1),
(13, 12, 1),
(14, 1, 2),
(15, 2, 2),
(16, 3, 2),
(17, 4, 2),
(18, 5, 2),
(19, 6, 2),
(20, 7, 2),
(21, 8, 2),
(22, 9, 2),
(23, 10, 2),
(24, 11, 2),
(25, 12, 2),
(26, 1, 3),
(27, 2, 3),
(28, 3, 3),
(29, 4, 3),
(30, 5, 3),
(31, 6, 3),
(32, 7, 3),
(33, 8, 3),
(34, 9, 3),
(35, 10, 3),
(36, 11, 3),
(37, 12, 3),
(38, 1, 4),
(39, 2, 4),
(40, 3, 4),
(41, 4, 4),
(42, 5, 4),
(43, 6, 4),
(44, 7, 4),
(45, 8, 4),
(46, 9, 4),
(47, 10, 4),
(48, 11, 4),
(49, 12, 4),
(50, 1, 5),
(51, 2, 5),
(52, 3, 5),
(53, 4, 5),
(54, 5, 5),
(55, 6, 5),
(56, 7, 5),
(57, 8, 5),
(58, 9, 5),
(59, 10, 5),
(60, 11, 5),
(61, 12, 5),
(62, 1, 6),
(63, 2, 6),
(64, 3, 6),
(65, 4, 6),
(66, 5, 6),
(67, 6, 6),
(68, 7, 6),
(69, 8, 6),
(70, 9, 6),
(71, 10, 6),
(72, 11, 6),
(73, 12, 6),
(74, 1, 7),
(75, 2, 7),
(76, 3, 7),
(77, 4, 7),
(78, 5, 7),
(79, 6, 7),
(80, 7, 7),
(81, 8, 7),
(82, 9, 7),
(83, 10, 7),
(84, 11, 7),
(85, 12, 7),
(86, 1, 8),
(87, 2, 8),
(88, 3, 8),
(89, 4, 8),
(90, 5, 8),
(91, 6, 8),
(92, 7, 8),
(93, 8, 8),
(94, 9, 8),
(95, 10, 8),
(96, 11, 8),
(97, 12, 8),
(98, 1, 9),
(99, 2, 9),
(100, 3, 9),
(101, 4, 9),
(102, 5, 9),
(103, 6, 9),
(104, 7, 9),
(105, 8, 9),
(106, 9, 9),
(107, 10, 9),
(108, 11, 9),
(109, 12, 9),
(110, 1, 10),
(111, 2, 10),
(112, 3, 10),
(113, 4, 10),
(114, 5, 10),
(115, 6, 10),
(116, 7, 10),
(117, 8, 10),
(118, 9, 10),
(119, 10, 10),
(120, 11, 10),
(121, 12, 10);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ezy_CardExpiry`
--
ALTER TABLE `ezy_CardExpiry`
  ADD PRIMARY KEY (`CardExpiryID`),
  ADD KEY `FK_CardExpiryMonth` (`CardExpiryMonthID`),
  ADD KEY `FK_CardExpiryYear` (`CardExpiryYearID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ezy_CardExpiry`
--
ALTER TABLE `ezy_CardExpiry`
  MODIFY `CardExpiryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=122;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ezy_CardExpiry`
--
ALTER TABLE `ezy_CardExpiry`
  ADD CONSTRAINT `FK_CardExpiryMonth` FOREIGN KEY (`CardExpiryMonthID`) REFERENCES `ezy_CardExpiryMonth` (`CardExpiryMonthID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CardExpiryYear` FOREIGN KEY (`CardExpiryYearID`) REFERENCES `ezy_CardExpiryYear` (`CardExpiryYearID`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
