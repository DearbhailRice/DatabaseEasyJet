-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 14, 2019 at 12:59 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drice21`
--

-- --------------------------------------------------------

--
-- Table structure for table `ezy_Route`
--

CREATE TABLE `ezy_Route` (
  `RouteID` int(11) NOT NULL,
  `DepartureAirportID` int(11) NOT NULL,
  `ArrivalAirportID` int(11) NOT NULL,
  `ApproxTimeTakenToFly` time NOT NULL,
  `Domestic` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ezy_Route`
--

INSERT INTO `ezy_Route` (`RouteID`, `DepartureAirportID`, `ArrivalAirportID`, `ApproxTimeTakenToFly`, `Domestic`) VALUES
(1, 22, 24, '02:00:00', 0),
(2, 30, 24, '02:00:00', 0),
(3, 24, 30, '02:00:00', 0),
(4, 30, 20, '01:31:00', 0),
(5, 20, 30, '01:30:00', 0),
(6, 14, 13, '03:00:00', 1),
(7, 13, 14, '03:00:00', 1),
(8, 14, 30, '03:00:00', 0),
(9, 23, 22, '04:00:00', 1),
(10, 22, 23, '02:45:00', 1),
(19, 30, 13, '04:00:00', 0),
(20, 13, 30, '04:00:00', 0),
(21, 16, 15, '01:00:00', 1),
(22, 15, 16, '01:00:00', 1),
(23, 25, 29, '05:00:00', 0),
(24, 29, 25, '05:00:00', 0),
(25, 17, 21, '03:00:00', 0),
(26, 21, 17, '03:00:00', 0),
(27, 18, 12, '02:00:00', 0),
(28, 12, 18, '02:00:00', 0),
(29, 30, 10, '01:45:00', 0),
(30, 10, 30, '01:45:00', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ezy_Route`
--
ALTER TABLE `ezy_Route`
  ADD PRIMARY KEY (`RouteID`),
  ADD KEY `FK_DepartAirportID` (`DepartureAirportID`),
  ADD KEY `FK_ArriveAirportID` (`ArrivalAirportID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ezy_Route`
--
ALTER TABLE `ezy_Route`
  MODIFY `RouteID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ezy_Route`
--
ALTER TABLE `ezy_Route`
  ADD CONSTRAINT `FK_ArriveAirportID` FOREIGN KEY (`ArrivalAirportID`) REFERENCES `ezy_Airport` (`AirportID`),
  ADD CONSTRAINT `FK_DepartAirportID` FOREIGN KEY (`DepartureAirportID`) REFERENCES `ezy_Airport` (`AirportID`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
