-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 14, 2019 at 12:56 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drice21`
--

-- --------------------------------------------------------

--
-- Table structure for table `ezy_Airport`
--

CREATE TABLE `ezy_Airport` (
  `AirportID` int(11) NOT NULL,
  `AirportName` varchar(255) NOT NULL,
  `AirportCode` varchar(3) NOT NULL,
  `Latitude` varchar(255) NOT NULL,
  `Longitude` varchar(255) NOT NULL,
  `CityID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ezy_Airport`
--

INSERT INTO `ezy_Airport` (`AirportID`, `AirportName`, `AirportCode`, `Latitude`, `Longitude`, `CityID`) VALUES
(9, 'W.A. Mozart', 'SZG', '47.7926° N ', '13.0029° E', 52),
(10, 'Dubrovnik', 'DBV', '42.5602° N', '18.2622° E', 32),
(11, 'Split', 'SPU', '43.5384° N', '16.2983° E', 32),
(12, 'Ruzyne', 'PRG', '50.1018° N', '14.2632° E', 50),
(13, 'Bordeaux Airport', 'BOD', '44.8306° N', '0.7103° W', 28),
(14, 'Lyon Saint Exupéry Airport', 'LYS', '45.7234° N', '5.0888° E', 43),
(15, 'Cote D\'Azur', 'NCE', '43.6598° N', '7.2148° E', 48),
(16, 'Charles De Gaulle', 'CDG', '49.0097° N', '2.5479° E', 49),
(17, 'Keflavik International', 'KEF', '63.9786° N', '22.6350° W', 51),
(18, 'Naples', 'NAP', '40.8847° N', '14.2892° E', 46),
(19, 'Marco Polo', 'VCE', '45.5063° N', '12.3475° E', 55),
(20, 'Schiphol', 'AMS', '52.3105° N', '4.7683° E', 25),
(21, 'J. Paul II Balice International', 'KRK', '50.0770° N', '19.7881° E', 40),
(22, 'Aeroporto Internacional de Faro', 'FAO', '37.008666632 N\r\n', ' 7.959496162 W', 34),
(23, 'El Altet Airport', 'ALC', '38.2855° N ', '0.5601° W', 24),
(24, 'Barcelona', 'BCN', '41.2974° N', '2.0833° E', 26),
(25, 'Fuerteventura', 'FUE', '28.4524° N', '13.8669° W', 30),
(29, 'George Best Belfast City ', 'BHD', '54.6176° N', '5.8718° W', 56),
(30, 'Belfast International ', 'BFS', '54.6618° N', '6.2162° W', 56);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ezy_Airport`
--
ALTER TABLE `ezy_Airport`
  ADD PRIMARY KEY (`AirportID`),
  ADD KEY `FK_CityID` (`CityID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ezy_Airport`
--
ALTER TABLE `ezy_Airport`
  MODIFY `AirportID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ezy_Airport`
--
ALTER TABLE `ezy_Airport`
  ADD CONSTRAINT `FK_CityID` FOREIGN KEY (`CityID`) REFERENCES `ezy_City` (`CityID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
