-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 14, 2019 at 12:58 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drice21`
--

-- --------------------------------------------------------

--
-- Table structure for table `ezy_PassangerAssistanceType`
--

CREATE TABLE `ezy_PassangerAssistanceType` (
  `PassangerAssistanceTypeID` int(11) NOT NULL,
  `PassangerAssistanceType` varbinary(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ezy_PassangerAssistanceType`
--

INSERT INTO `ezy_PassangerAssistanceType` (`PassangerAssistanceTypeID`, `PassangerAssistanceType`) VALUES
(6, 0xf94496bd499cd7f563885cb9aceb5d89fce316a66afa724dbccdb123c2d17664),
(7, 0xaf4726c53a4e79d752910db7322ded65781169288d26fcd9a66d9da3aa02cb30),
(8, 0x5781f212b7ec409721f0bd2738ed1b68946da5d696639fdad9c28425eee8f2db),
(9, 0xa51ea40068426c3e7817a2bf39033c6071d4d84d7d8e9040783c4055eab4fada),
(10, 0x176bc9768d4504398b0202b6fc7bf098348c72e6f16ba6802f0a1f046178affab148b9ba488cd98cb10a2da0475c49da),
(11, 0x266fcac13190013f59156612b586828b);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ezy_PassangerAssistanceType`
--
ALTER TABLE `ezy_PassangerAssistanceType`
  ADD PRIMARY KEY (`PassangerAssistanceTypeID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ezy_PassangerAssistanceType`
--
ALTER TABLE `ezy_PassangerAssistanceType`
  MODIFY `PassangerAssistanceTypeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
