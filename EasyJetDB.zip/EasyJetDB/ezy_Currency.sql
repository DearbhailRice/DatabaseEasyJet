-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 14, 2019 at 12:58 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drice21`
--

-- --------------------------------------------------------

--
-- Table structure for table `ezy_Currency`
--

CREATE TABLE `ezy_Currency` (
  `CurrencyID` int(11) NOT NULL,
  `Currency` varchar(255) NOT NULL,
  `Symbol` varchar(255) DEFAULT NULL,
  `DigitalCode` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ezy_Currency`
--

INSERT INTO `ezy_Currency` (`CurrencyID`, `Currency`, `Symbol`, `DigitalCode`) VALUES
(1, 'AED', '', 784),
(2, 'AFN', 'Af', 971),
(3, 'ALL', 'L', 8),
(4, 'AMD', '?', 51),
(5, 'AOA', 'Kz', 973),
(6, 'ARS', '$', 32),
(7, 'AUD', '$', 36),
(8, 'AWG', 'ƒ', 533),
(9, 'AZN', '???', 944),
(10, 'BAM', '??', 977),
(11, 'BBD', '$', 52),
(12, 'BDT', '?', 50),
(13, 'BGN', '??', 975),
(14, 'BHD', '', 48),
(15, 'BIF', '?', 108),
(16, 'BMD', '$', 60),
(17, 'BND', '$', 96),
(18, 'BOB', 'Bs.', 68),
(19, 'BRL', 'R$', 986),
(20, 'BSD', '$', 44),
(21, 'BTN', '', 64),
(22, 'BWP', 'P', 72),
(23, 'BYR', 'Br', 974),
(24, 'BZD', '$', 84),
(25, 'CAD', '$', 124),
(26, 'CDF', '?', 976),
(27, 'CHF', '?', 756),
(28, 'CLP', '$', 152),
(29, 'CNY', '¥', 156),
(30, 'COP', '$', 170),
(31, 'CRC', '?', 188),
(32, 'CUP', '$', 192),
(33, 'CVE', '$', 132),
(34, 'CZK', 'K?', 203),
(35, 'DJF', '?', 262),
(36, 'DKK', 'kr', 208),
(37, 'DOP', '$', 214),
(38, 'DZD', '', 12),
(39, 'EGP', '£', 818),
(40, 'ERN', 'Nfk', 232),
(41, 'ETB', '', 230),
(42, 'EUR', '€', 978),
(43, 'FJD', '$', 242),
(44, 'FKP', '£', 238),
(45, 'GBP', '£', 826),
(46, 'GEL', '?', 981),
(47, 'GHS', '?', 936),
(48, 'GIP', '£', 292),
(49, 'GMD', 'D', 270),
(50, 'GNF', '?', 324),
(51, 'GTQ', 'Q', 320),
(52, 'GYD', '$', 328),
(53, 'HKD', '$', 344),
(54, 'HNL', 'L', 340),
(55, 'HRK', 'Kn', 191),
(56, 'HTG', 'G', 332),
(57, 'HUF', 'Ft', 348),
(58, 'IDR', 'Rp', 360),
(59, 'ILS', '?', 376),
(60, 'INR', '?', 356),
(61, 'IQD', '?.?', 368),
(62, 'IRR', '?', 364),
(63, 'ISK', 'Kr', 352),
(64, 'JMD', '$', 388),
(65, 'JOD', '?.?', 400),
(66, 'JPY', '¥', 392),
(67, 'KES', 'Sh', 404),
(68, 'KGS', '', 417),
(69, 'KHR', '?', 116),
(70, 'KPW', '?', 408),
(71, 'KRW', '?', 410),
(72, 'KWD', '?.?', 414),
(73, 'KYD', '$', 136),
(74, 'KZT', '?', 398),
(75, 'LAK', '?', 418),
(76, 'LBP', '?.?', 422),
(77, 'LKR', 'Rs', 144),
(78, 'LRD', '$', 430),
(79, 'LSL', 'L', 426),
(80, 'LYD', '?.?', 434),
(81, 'MAD', '?.?.', 504),
(82, 'MDL', 'L', 498),
(83, 'MGA', '', 969),
(84, 'MKD', '???', 807),
(85, 'MMK', 'K', 104),
(86, 'MNT', '?', 496),
(87, 'MOP', 'P', 446),
(88, 'MRO', 'UM', 478),
(89, 'MUR', '?', 480),
(90, 'MVR', '?.', 462),
(91, 'MWK', 'MK', 454),
(92, 'MXN', '$', 484),
(93, 'MYR', 'RM', 458),
(94, 'MZN', 'MTn', 943),
(95, 'NAD', '$', 516),
(96, 'NGN', '?', 566),
(97, 'NIO', 'C$', 558),
(98, 'NOK', 'kr', 578),
(99, 'NPR', '?', 524),
(100, 'NZD', '$', 554),
(101, 'OMR', '?.?.', 512),
(102, 'PAB', 'B/.', 590),
(103, 'PEN', 'S/.', 604),
(104, 'PGK', 'K', 598),
(105, 'PHP', '?', 608),
(106, 'PKR', '?', 586),
(107, 'PLN', 'z?', 985),
(108, 'PYG', '?', 600),
(109, 'QAR', '?.?', 634),
(110, 'RON', 'L', 946),
(111, 'RSD', 'din', 941),
(112, 'RUB', '?.', 643),
(113, 'RWF', '?', 646),
(114, 'SAR', '?.?', 682),
(115, 'SBD', '$', 90),
(116, 'SCR', '?', 690),
(117, 'SDG', '£', 938),
(118, 'SEK', 'kr', 752),
(119, 'SGD', '$', 702),
(120, 'SHP', '£', 654),
(121, 'SLL', 'Le', 694),
(122, 'SOS', 'Sh', 706),
(123, 'SRD', '$', 968),
(124, 'STD', 'Db', 678),
(125, 'SYP', '?.?', 760),
(126, 'SZL', 'L', 748),
(127, 'THB', '?', 764),
(128, 'TJS', '??', 972),
(129, 'TMT', 'm', 934),
(130, 'TND', '?.?', 788),
(131, 'TOP', 'T$', 776),
(132, 'TRY', '?', 949),
(133, 'TTD', '$', 780),
(134, 'TWD', '$', 901),
(135, 'TZS', 'Sh', 834),
(136, 'UAH', '?', 980),
(137, 'UGX', 'Sh', 800),
(138, 'USD', '$', 840),
(139, 'UYU', '$', 858),
(140, 'UZS', '', 860),
(141, 'VEF', 'Bs F', 937),
(142, 'VND', '?', 704),
(143, 'VUV', 'Vt', 548),
(144, 'WST', 'T', 882),
(145, 'XAF', '?', 950),
(146, 'XCD', '$', 951),
(147, 'XPF', '?', 953),
(148, 'YER', '?', 886),
(149, 'ZAR', 'R', 710),
(150, 'ZMW', 'ZK', 967),
(151, 'ZWL', '$', 932);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ezy_Currency`
--
ALTER TABLE `ezy_Currency`
  ADD PRIMARY KEY (`CurrencyID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ezy_Currency`
--
ALTER TABLE `ezy_Currency`
  MODIFY `CurrencyID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=152;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
